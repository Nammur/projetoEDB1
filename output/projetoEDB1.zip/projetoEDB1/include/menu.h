#include <iostream>
#include <time.h>
#include <algorithm>

void menu(int *Array, int *ArrayIndex,int tamanhoVetor, int selecaoVetor);
void copiar(int *Array, int *copia, int tamanhoVetor);
void copiarReverso(int *Array, int *copia, int tamanhoVetor);
void printArray(int *Array, int tamanhoVetor);