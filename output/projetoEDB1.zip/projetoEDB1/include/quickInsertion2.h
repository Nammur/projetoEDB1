#include <iostream>
#include <time.h>
#include <algorithm>

void quickInsertion2(int *Array, int inicio, int tamanhoVetor);