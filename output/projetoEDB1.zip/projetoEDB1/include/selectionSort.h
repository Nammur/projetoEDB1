#include <iostream>
#include <time.h>
#include <algorithm>

void SelectionSort(int *Array, int tam);