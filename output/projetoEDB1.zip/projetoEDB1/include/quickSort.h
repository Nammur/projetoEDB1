#include <iostream>
#include <time.h>
#include <algorithm>

void quickSort(int  *Array,int inicio, int  tamanhoVetor);