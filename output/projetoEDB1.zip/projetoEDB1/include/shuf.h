#include <iostream>
#include <time.h>
#include <algorithm>

void shuf(int *Array,int *ArrayIndex, int range, int elemento1, int elemento2);