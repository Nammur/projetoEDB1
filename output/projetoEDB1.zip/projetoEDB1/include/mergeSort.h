#include <iostream>
#include <time.h>
#include <algorithm>

void mergeSort(int *Array, int begin, int tamanhoVetor);