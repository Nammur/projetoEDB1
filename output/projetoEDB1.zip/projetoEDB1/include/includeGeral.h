#include <iostream>
#include <time.h>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <string>

#include "../include/insertionSort.h"
#include "../include/bubbleSort.h"
#include "../include/quickSort.h"
#include "../include/shuf.h"
#include "../include/mergeSort.h"
#include "../include/selectionSort.h"
#include "../include/menu.h"
#include "../include/shellSort.h"
#include "../include/radixSort.h"
#include "../include/quickInsertion2.h"